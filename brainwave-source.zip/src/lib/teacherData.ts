// ===== Teaching outlines for teachers — programme overviews, topic guides, activities =====
// No quiz questions here. This is guidance for teachers to deliver each topic.

export type TeachingTopic = {
  id: string;
  name: string;
  icon: string;
  description: string;
  objectives: string[];
  guidance: string;
  activities: string[];
  misconceptions: string[];
};

export type TeachingSection = {
  id: string;
  name: string;
  subtitle: string;
  overview: string;
  topics: TeachingTopic[];
};

export type TeachingProgramme = {
  id: string;
  name: string;
  description: string;
  color: string;
  icon: string;
  sections: TeachingSection[];
};

/* ===================== PRIMARY (Years 1-8) ===================== */

const PRIMARY_SECTIONS: TeachingSection[] = [
  {
    id: "year1",
    name: "Year 1",
    subtitle: "Ages 5-6",
    overview: "Year 1 builds the foundations of number sense. The focus is on counting confidently to 20, understanding addition and subtraction as real actions, recognising shapes, and spotting patterns. Keep everything concrete — use physical objects, fingers, and pictures. Short, playful sessions work best at this age.",
    topics: [
      {
        id: "counting", name: "Counting", icon: "Hash", description: "Count up to 20.",
        objectives: ["Count forwards and backwards to 20", "Understand the last number said is the total", "Count objects one-to-one accurately"],
        guidance: "Start by counting real objects — counters, fingers, fruit. Emphasise touching or pointing to each item as you count. Practice counting both forwards and backwards, as backwards builds the foundation for subtraction. Use number lines visually.",
        activities: ["Counting walk: count steps, trees, or cars outside", "Grab-and-count: give children a handful of objects to count", "Missing number: write 1-10 on cards, remove one, ask which is missing"],
        misconceptions: ["Skipping numbers when counting (e.g. 1,2,3,5)", "Not understanding the last number is the total — recounting instead of answering 'how many'", "Counting an object twice or missing one when counting quickly"],
      },
      {
        id: "adding-small", name: "Adding Small Numbers", icon: "Plus", description: "Add numbers up to 10.",
        objectives: ["Understand addition as combining groups", "Add single-digit numbers to total 10", "Use the '+' symbol correctly"],
        guidance: "Teach addition as 'putting together'. Start with physical objects — 2 blocks and 3 blocks make 5. Move to pictures, then to numbers. Teach that addition can be done in any order (2+3 = 3+2). Use fingers as a backup tool.",
        activities: ["Counter story: '2 frogs jumped on a log, then 3 more came — how many?'", "Dice addition: roll two dice and add the numbers", "Ten-frame fill: use a ten-frame to show addition visually"],
        misconceptions: ["Counting up from 1 instead of counting on from the larger number", "Forgetting that adding 0 doesn't change the number", "Confusing '+' with '-'"],
      },
      {
        id: "take-away-small", name: "Taking Away", icon: "Minus", description: "Subtract small numbers.",
        objectives: ["Understand subtraction as removing from a group", "Subtract single-digit numbers within 10", "Use the '−' symbol correctly"],
        guidance: "Teach subtraction as 'taking away'. Start with objects: 'You have 5 counters, I take 2 — how many are left?' Then move to crossing out pictures. Emphasise that the answer is smaller than what you started with (unless you take away 0).",
        activities: ["Bowl game: put 6 counters in a bowl, remove some while the child closes their eyes — how many were taken?", "Cross-out pictures: draw 5 apples, cross out 2", "Number line jumps: start at 7, jump back 3"],
        misconceptions: ["Subtracting the smaller number from the larger (e.g. 5-8 instead of 8-5)", "Not understanding that taking everything leaves 0", "Counting the starting number when counting back (e.g. 7-3: counting 7,6,5 and saying 5 instead of 4)"],
      },
      {
        id: "shapes-y1", name: "Shapes", icon: "Shapes", description: "Recognise simple shapes.",
        objectives: ["Recognise and name circle, triangle, square, rectangle", "Count sides and corners", "Identify shapes in the real world"],
        guidance: "Use physical shape cutouts. Let children hold and trace shapes. Focus on counting sides and corners to distinguish them. Point out shapes in the classroom and outside — a door is a rectangle, a wheel is a circle.",
        activities: ["Shape hunt: find circles, squares, triangles around the room", "Shape sorting: sort cutouts into groups", "Play-dough shapes: make shapes with dough and count their sides"],
        misconceptions: ["Calling any 4-sided shape a square (not recognising rectangles)", "Thinking a circle has corners", "Confusing a triangle with a square because both have 'pointy' bits"],
      },
      {
        id: "patterns-y1", name: "Patterns", icon: "Sparkles", description: "Spot and continue patterns.",
        objectives: ["Identify repeating patterns", "Continue a given pattern", "Create own patterns"],
        guidance: "Start with simple AB patterns (red, blue, red, blue) using coloured blocks. Ask 'what comes next?' Then move to AAB and ABC patterns. Connect to number patterns (2, 4, 6, 8...) to build early times-tables awareness.",
        activities: ["Bead patterns: thread beads in a repeating colour pattern", "Clap-stomp patterns: use body movements to make patterns", "Number line hopscotch: hop on numbers following a +2 pattern"],
        misconceptions: ["Guessing randomly instead of finding the rule", "Noticing the colour but not the sequence rule", "Struggling when the pattern unit is longer (AAB instead of AB)"],
      },
    ],
  },
  {
    id: "year2",
    name: "Year 2",
    subtitle: "Ages 6-7",
    overview: "Year 2 extends number work to 20, introduces the 2, 5, and 10 times tables, and brings in money and simple fractions. Children start to solve word problems. Use real-world contexts like shopping to make the maths meaningful.",
    topics: [
      {
        id: "numbers-to-20", name: "Numbers to 20", icon: "Hash", description: "Place value and ordering to 20.",
        objectives: ["Read, write and order numbers to 20", "Understand tens and ones", "Compare numbers using 'more than' and 'less than'"],
        guidance: "Use ten-frames and base-10 blocks to show that 14 is one ten and four ones. Have children build numbers physically. Practice ordering numbers on a number line and using 'greater than' and 'less than' language.",
        activities: ["Build-and-compare: children build two numbers with blocks and say which is bigger", "Number card ordering: shuffle 1-20 cards and have children put them in order", "Tens and ones game: show a number, children build it with sticks (tens) and cubes (ones)"],
        misconceptions: ["Writing teen numbers backwards (e.g. 41 for 14) — they hear 'four-teen' and write 4 first", "Not understanding that 12 is 10+2, treating it as 1 and 2 separately", "Confusing 'greater than' direction"],
      },
      {
        id: "add-subtract-20", name: "Add & Subtract to 20", icon: "Plus", description: "Mental strategies within 20.",
        objectives: ["Add and subtract within 20", "Count on from the larger number", "Bridge through 10 using number bonds"],
        guidance: "Teach 'counting on' — for 7+3, start at 7 and count 8, 9, 10. Then teach bridging through 10: for 8+5, split 5 into 2+3, add 2 to make 10, then add 3. Number bonds to 10 (pairs that make 10) are essential here.",
        activities: ["Number bond bingo: call a number, children write its partner to 10", "Bridging game: use a number line to show the jump to 10 then beyond", "Story problems: '7 birds on a branch, 5 more flew in...'"],
        misconceptions: ["Counting on including the starting number (7+3: saying 7,8,9 instead of 8,9,10)", "Not using number bonds to bridge 10", "Still counting all instead of counting on"],
      },
      {
        id: "times-tables-2-5-10", name: "Times Tables (2, 5, 10)", icon: "Multiply", description: "Begin multiplication.",
        objectives: ["Understand multiplication as repeated addition", "Recall 2x, 5x and 10x tables", "Solve simple multiplication problems"],
        guidance: "Start with the concept of groups: '3 groups of 2'. Use arrays (rows of dots) to show this visually. The 10x table is easiest (just add a zero), then 2x (doubles), then 5x (skip count by 5). Practice with songs, chanted counting, and games.",
        activities: ["Array building: make 3 rows of 4 counters", "Skip-count songs: chant 2, 4, 6, 8... and 5, 10, 15, 20...", "Multiplication war: card game where players multiply flipped cards"],
        misconceptions: ["Treating 3x2 and 2x3 as different (not understanding commutativity yet)", "Counting all instead of using skip-counting or recall", "Confusing multiplication with addition"],
      },
      {
        id: "money-y2", name: "Money", icon: "Coins", description: "Coins and simple shopping.",
        objectives: ["Recognise coins and their values", "Make amounts with coins", "Give change from 20p"],
        guidance: "Use real or plastic coins. Start by sorting coins by value. Then practice making amounts (e.g. 'make 15p'). Counting in 2s, 5s and 10s helps with money. Introduce giving change by counting up to the amount paid.",
        activities: ["Shop role-play: set up a classroom shop with price tags", "Coin matching: match coins to price cards", "Change challenge: 'You buy something for 12p and pay 20p — what change do you get?'"],
        misconceptions: ["Confusing coin size with value (thinking a 2p is worth more than a 5p because it's bigger)", "Not counting coins correctly when mixing denominations", "Adding the number of coins instead of their values"],
      },
      {
        id: "fractions-y2", name: "Simple Fractions", icon: "PieChart", description: "Half and quarter.",
        objectives: ["Understand 1/2 and 1/4", "Find half of a shape and a quantity", "Recognise that two halves make a whole"],
        guidance: "Start with shapes — fold paper in half to show equal parts. Emphasise that halves must be EQUAL. Then find half of quantities (half of 8 = 4). Use real food (pizza, cake) to make it memorable.",
        activities: ["Folding paper: fold squares and circles into halves and quarters", "Sharing game: 'Share these 10 sweets equally between 2 people'", "Fraction pizza: cut paper pizzas into halves and quarters"],
        misconceptions: ["Thinking any two pieces are halves (not checking they're equal)", "Confusing 1/2 and 1/4", "Thinking 1/4 is bigger than 1/2 because 4 is bigger than 2"],
      },
    ],
  },
  {
    id: "year3",
    name: "Year 3",
    subtitle: "Ages 7-8",
    overview: "Year 3 extends to the full 12 times tables, introduces simple fractions as numbers, and brings in measuring (length, mass, capacity). Word problems become more common. Children should start showing their working.",
    topics: [
      {
        id: "times-tables-12", name: "Times Tables to 12", icon: "Multiply", description: "All times tables up to 12x12.",
        objectives: ["Recall all times tables up to 12x12", "Understand multiplication as repeated addition and arrays", "Use multiplication to solve word problems"],
        guidance: "Build on the 2, 5, 10 tables from Year 2. Introduce 3, 4, 6, 8 next, then 7, 9, 11, 12. Use arrays, skip-counting, and patterns (e.g. 9x: the digits add to 9). Regular short practice is better than long sessions. Times-table songs and games help.",
        activities: ["Times-table bingo: call the answer, children find the question", "Array art: draw arrays for different facts", "Pattern hunt: find patterns in the 9x table (digits sum to 9)"],
        misconceptions: ["Memorising in order but struggling with random facts", "Not understanding commutativity fully (7x8 vs 8x7)", "Confusing 6x7 and 7x6 — and getting 6x7=42 wrong (the most-missed fact)"],
      },
      {
        id: "fractions-y3", name: "Fractions", icon: "PieChart", description: "Fractions as numbers.",
        objectives: ["Understand unit and non-unit fractions", "Find fractions of quantities", "Compare simple fractions"],
        guidance: "Move beyond halves and quarters to thirds, sixths, eighths. Use fraction walls and bar models to compare fractions. Teach finding a fraction of a quantity by dividing by the denominator (1/3 of 12 = 12 ÷ 3 = 4).",
        activities: ["Fraction wall: build a wall with paper strips in different fractions", "Bar model: find 1/4 of 20 using a bar model", "Fraction pairs: match equivalent pictures (1/2 = 2/4)"],
        misconceptions: ["Thinking 1/3 is smaller than 1/4 (bigger denominator = smaller fraction, but the reasoning is tricky)", "Adding numerators and denominators (1/2 + 1/3 = 2/5 — wrong)", "Not dividing by the denominator when finding a fraction of a quantity"],
      },
      {
        id: "measuring-y3", name: "Measuring", icon: "Ruler", description: "Length, mass and capacity.",
        objectives: ["Measure using cm, g, and ml", "Read scales accurately", "Compare and order measurements"],
        guidance: "Use real measuring tools — rulers, scales, measuring jugs. Teach reading scales by identifying what each mark represents. Always include units. Compare measurements by converting to the same unit first.",
        activities: ["Measure the classroom: measure desks, books, and the door in cm", "Water play: measure capacity with measuring jugs", "Weighing station: compare the mass of classroom objects"],
        misconceptions: ["Not starting from 0 on a ruler", "Mixing up units (cm and mm)", "Not reading the scale correctly — counting marks instead of reading values"],
      },
      {
        id: "word-problems-y3", name: "Word Problems", icon: "FileText", description: "Two-step problems.",
        objectives: ["Identify the operation(s) needed in a word problem", "Solve two-step problems", "Show working clearly"],
        guidance: "Teach a problem-solving routine: read twice, underline key numbers and words, decide the operation, solve, check. Use bar models to visualise. Start with one-step problems, then move to two-step. Encourage children to draw the problem.",
        activities: ["Bar model drawing: represent word problems with bars", 'Act it out: children role-play the problem', "Write your own: children write a word problem for a partner to solve"],
        misconceptions: ["Guessing the operation from a keyword without understanding the problem", "Not reading the question — answering a different question than asked", "Forgetting the second step in two-step problems"],
      },
    ],
  },
  {
    id: "year4",
    name: "Year 4",
    subtitle: "Ages 8-9",
    overview: "Year 4 introduces larger numbers (to 10,000), formal written methods for addition and subtraction, and the relationship between fractions and decimals. Area and perimeter are introduced. Children should be fluent in all times tables by the end of Year 4.",
    topics: [
      {
        id: "place-value-y4", name: "Place Value to 10,000", icon: "Hash", description: "Thousands, hundreds, tens, ones.",
        objectives: ["Read, write and order numbers to 10,000", "Understand the value of each digit", "Round to the nearest 10, 100 and 1000"],
        guidance: "Use place-value charts and base-10 equipment. Show that 3,452 is 3000 + 400 + 50 + 2. Teach rounding by looking at the digit to the right: 5 or more, round up; 4 or less, round down. Use number lines to show which multiple is nearest.",
        activities: ["Place-value cards: build 4-digit numbers and swap digits", "Rounding game: round numbers to nearest 100 on a number line", "What's my number? — give clues using place value"],
        misconceptions: ["Writing 4000+300+20+1 as 4321 correctly but struggling when a digit is 0 (e.g. 4027 — losing the tens)", "Rounding down when the digit is 5 (it should round up)", "Reversing digits in thousands numbers"],
      },
      {
        id: "written-methods-y4", name: "Written Methods", icon: "Plus", description: "Column addition and subtraction.",
        objectives: ["Add using column method with regrouping", "Subtract using column method with exchanging", "Apply to 4-digit numbers"],
        guidance: "Start with expanded column method (showing each step) then move to compact. Emphasise place value: line up digits correctly. Teach regrouping ('carrying') for addition and exchanging ('borrowing') for subtraction with base-10 blocks first, then on paper.",
        activities: ["Base-10 addition: add with blocks, then record on paper", "Error analysis: find the mistake in a pre-done calculation", "Estimate-first: estimate the answer before calculating precisely"],
        misconceptions: ["Not aligning digits by place value (ones under tens)", "Forgetting to regroup when the column totals more than 9", "In subtraction, exchanging from a column with 0 without continuing to borrow"],
      },
      {
        id: "fractions-decimals-y4", name: "Fractions & Decimals", icon: "PieChart", description: "Tenths and hundredths.",
        objectives: ["Understand tenths and hundredths as decimals", "Convert between simple fractions and decimals", "Order decimals"],
        guidance: "Use a place-value chart extending to tenths and hundredths. Show that 0.3 = 3/10 and 0.07 = 7/100. Use hundred squares to shade decimals. Compare decimals by looking at the tenths digit first.",
        activities: ["Decimal hundred square: shade 0.35 on a hundred square", "Fraction-decimal match: match 1/2, 1/4, 3/4 to 0.5, 0.25, 0.75", "Decimal ordering: order 0.4, 0.04, 0.44 from smallest to largest"],
        misconceptions: ["Thinking 0.04 is bigger than 0.4 (4 is bigger than... wait, the place value matters)", "Writing 3/10 as 0.3 but 3/100 as 0.3 (should be 0.03)", "Not aligning decimal points when comparing"],
      },
      {
        id: "area-perimeter-y4", name: "Area & Perimeter", icon: "Ruler", description: "Squares and rectangles.",
        objectives: ["Calculate perimeter by adding sides", "Calculate area by counting squares", "Use the formula area = length × width"],
        guidance: "Start with counting squares on grid paper to find area. Then show that area = length × width. For perimeter, walk around the edge of a shape and add all sides. Use real objects — measure and calculate the area of a book or desk.",
        activities: ["Grid area: draw shapes on squared paper and find their area", "Perimeter walk: measure the classroom perimeter with a trundle wheel", "Design a garden: children draw a rectangular garden and calculate its area and perimeter"],
        misconceptions: ["Confusing area and perimeter", "Counting the corner squares twice when finding area by counting", "Forgetting that perimeter uses all sides, not just length and width"],
      },
    ],
  },
  {
    id: "year5",
    name: "Year 5",
    subtitle: "Ages 9-10",
    overview: "Year 5 introduces percentages, long division, angles, and data handling. Children work with increasingly large numbers and develop formal written methods for all four operations. Problem-solving becomes multi-step.",
    topics: [
      {
        id: "percentages-y5", name: "Percentages", icon: "Percent", description: "Understanding percentages.",
        objectives: ["Understand percentage as parts per 100", "Find percentages of amounts", "Convert between fractions, decimals and percentages"],
        guidance: "Start with the concept: percent means 'out of 100'. Show that 50% = 50/100 = 0.5. Teach finding 10% first (divide by 10), then build up (20% = double 10%, 5% = half of 10%). Use hundred squares to shade percentages.",
        activities: ["Percentage hundred square: shade different percentages", "Shop sale: '20% off £50 — how much do you save?'", "Fraction-decimal-percentage trio: match 1/2, 0.5, 50%"],
        misconceptions: ["Treating 5% as 1/5 (it's 5/100)", "Finding 10% by dividing by 100 instead of 10", "Not connecting fractions, decimals and percentages as the same idea"],
      },
      {
        id: "long-division-y5", name: "Long Division", icon: "Divide", description: "Formal division method.",
        objectives: ["Divide using the formal long division method", "Interpret remainders in context", "Divide up to 4-digit by 1-digit"],
        guidance: "Start with the 'bus stop' method for short division, then introduce long division for dividing by 2-digit numbers. Use place-value counters to model the steps. Teach children to check with multiplication (quotient × divisor = dividend).",
        activities: ["Place-value counter division: model division with equipment", "Remainder stories: '23 children, 4 per team — how many teams and how many left over?'", "Check with multiplication: divide, then multiply to check"],
        misconceptions: ["Not understanding what the remainder means in context (round up vs down vs express as fraction)", "Losing track of place value in the long division layout", "Writing the remainder in the wrong place"],
      },
      {
        id: "angles-y5", name: "Angles", icon: "Triangle", description: "Measuring and drawing angles.",
        objectives: ["Measure angles with a protractor", "Know angles on a line total 180° and around a point 360°", "Classify angles as acute, right, obtuse, reflex"],
        guidance: "Start by classifying angles (acute < 90°, right = 90°, obtuse 90-180°, reflex > 180°). Then teach protractor use: line up the centre, one side on 0, read the correct scale. Show that angles on a straight line total 180°.",
        activities: ["Angle hunt: find angles in the classroom and classify them", "Protractor practice: draw angles of given sizes", "Tear-and-test: tear angles from paper, measure them, check they fit on a straight line to make 180°"],
        misconceptions: ["Reading the wrong scale on the protractor (inside vs outside)", "Not lining up the protractor centre on the vertex", "Confusing acute and obtuse"],
      },
      {
        id: "data-y5", name: "Data Handling", icon: "BarChart3", description: "Charts and graphs.",
        objectives: ["Read and interpret bar charts and line graphs", "Collect and organise data", "Calculate the mean (average)"],
        guidance: "Use real data — heights, shoe sizes, favourite foods. Teach children to read scales carefully on graphs. Introduce the mean as 'total ÷ number of values'. Start with line graphs showing change over time (e.g. temperature across a day).",
        activities: ["Class survey: collect data and make a bar chart", "Temperature graph: record temperature over a week and plot a line graph", "Mean challenge: find the mean of five test scores"],
        misconceptions: ["Misreading the scale on a graph (especially when it goes up in 2s or 5s)", "Calculating mean by finding the middle instead of dividing the total", "Not labelling graph axes"],
      },
    ],
  },
  {
    id: "year6",
    name: "Year 6",
    subtitle: "Ages 10-11",
    overview: "Year 6 is the bridge to secondary maths. It introduces algebra basics, ratios, more complex geometry, and averages. This is the Checkpoint year, so exam preparation is important. Children should be confident with all four operations and ready for formal assessments.",
    topics: [
      {
        id: "algebra-basics-y6", name: "Algebra Basics", icon: "Sigma", description: "Variables and simple equations.",
        objectives: ["Use letters to represent unknown numbers", "Solve simple one-step equations", "Express relationships as formulas"],
        guidance: "Introduce algebra as 'finding the mystery number'. Start with concrete examples: 'I think of a number, add 5, the answer is 12 — what was my number?' Use a balance model to show that both sides of an equation must be equal.",
        activities: ["Mystery number: 'Think of a number, double it, add 3, answer is 15 — what was it?'", "Balance scales: use a physical or drawn balance to model equations", "Formula puzzles: write a formula for the perimeter of a rectangle"],
        misconceptions: ["Treating the letter as a specific unknown (thinking x always = 5)", "Not doing the same operation to both sides of an equation", "Confusing 3x (three times x) with x+3"],
      },
      {
        id: "ratio-proportion-y6", name: "Ratio & Proportion", icon: "Scale", description: "Ratios and scaling.",
        objectives: ["Understand ratio as comparing quantities", "Simplify ratios", "Solve proportion problems"],
        guidance: "Start with concrete ratios: '2 red counters to 3 blue counters'. Show that ratio is about relationship. Teach simplifying by dividing both sides by the same number. Use scaling problems: 'If 4 cakes cost $8, how much do 6 cakes cost?'",
        activities: ["Ratio recipe: scale a recipe up or down using ratios", "Counter ratios: build ratios with coloured counters and simplify", "Map scales: use a simple map scale to find real distances"],
        misconceptions: ["Confusing ratio with fraction (2:3 is not the same as 2/3)", "Not simplifying fully (leaving 4:6 instead of 2:3)", "Scaling the wrong direction in proportion problems"],
      },
      {
        id: "geometry-y6", name: "Geometry", icon: "Shapes", description: "Properties of shapes and angles.",
        objectives: ["Classify 2D and 3D shapes", "Find unknown angles using rules", "Calculate area of triangles and parallelograms"],
        guidance: "Review shape properties (sides, faces, vertices, angles). Teach angle rules: angles in a triangle = 180°, on a line = 180°, around a point = 360°. Show that area of a triangle = ½ × base × height by cutting a rectangle diagonally.",
        activities: ["Shape sort: classify shapes by properties", "Missing angle: find the missing angle in a triangle", "Triangle area: cut a paper rectangle diagonally to show why triangle area is ½ × base × height"],
        misconceptions: ["Confusing the height of a triangle (it must be perpendicular to the base, not a side)", "Adding only two angles in a triangle instead of all three", "Mixing up 2D and 3D shape vocabulary"],
      },
      {
        id: "averages-y6", name: "Averages", icon: "BarChart3", description: "Mean, median, mode, range.",
        objectives: ["Calculate mean, median, mode and range", "Choose the most appropriate average", "Interpret averages in context"],
        guidance: "Teach each average with a memorable hook: mean = 'share it out equally', median = 'middle', mode = 'most common'. Use small data sets first. Emphasise that the mean requires adding and dividing, while the median requires ordering first.",
        activities: ["Dice averages: roll 5 dice, find all four averages", 'Class data: find the median height of the class', "Which average? — discuss which average best describes different data sets"],
        misconceptions: ["Finding median without sorting the data first", "Confusing mode (most frequent) with the largest value", "Calculating range by subtracting 1 from the highest instead of subtracting the lowest"],
      },
    ],
  },
  {
    id: "year7",
    name: "Year 7",
    subtitle: "Ages 11-12",
    overview: "Year 7 is the start of secondary maths. It introduces integers (including negatives), powers and roots, sequences, and a more formal approach to algebra. Expectations for showing working and using correct notation increase.",
    topics: [
      {
        id: "integers-y7", name: "Integers & Negatives", icon: "Plus", description: "Working with negative numbers.",
        objectives: ["Order positive and negative integers", "Add and subtract negative numbers", "Multiply and divide with negatives"],
        guidance: "Use number lines extending below zero. For addition/subtraction, use the 'direction' model: adding a negative moves left, subtracting a negative moves right. For multiplication, teach the sign rules: same signs = positive, different signs = negative. Temperature and debt analogies help.",
        activities: ["Temperature game: add and subtract temperatures using a number line", "Debt analogy: 'I owe $5, then I owe $3 more — what's my total debt?'", "Sign rule patterns: investigate (-2)×(-3) using repeated addition"],
        misconceptions: ["Thinking -5 is bigger than -3 (confusing magnitude with position on the number line)", "Writing -3 - (-5) = -8 (should be +2)", "Always making the answer negative when negatives are involved"],
      },
      {
        id: "powers-roots-y7", name: "Powers & Roots", icon: "Sigma", description: "Squares, cubes and roots.",
        objectives: ["Calculate squares and cubes of numbers", "Find square roots and cube roots", "Use index notation correctly"],
        guidance: "Start with square numbers as 'a number multiplied by itself' — build arrays to show 3² = 9. Then introduce cube numbers with 3D models (3³ = 27 small cubes). Teach that square root is the inverse of squaring. Memorise squares to 12².",
        activities: ["Square array: build square arrays to visualise square numbers", "Cube building: build cubes with small blocks to show 2³, 3³, 4³", "Square root race: call a perfect square, first to give its root wins"],
        misconceptions: ["Confusing 2³ (=8) with 3² (=9)", "Thinking the square root of 16 is 8 (dividing by 2 instead of finding the root)", "Writing 3² as 6 (multiplying 3×2 instead of 3×3)"],
      },
      {
        id: "sequences-y7", name: "Sequences", icon: "TrendingUp", description: "Number patterns and rules.",
        objectives: ["Continue sequences given a rule", "Find the nth term of a linear sequence", "Describe sequences in words"],
        guidance: "Start with arithmetic sequences (constant difference). Show that the nth term = difference × n + adjustment. For 5, 8, 11, 14... the difference is 3, and the first term is 5 = 3×1+2, so the nth term is 3n+2. Use matchstick patterns to make it visual.",
        activities: ["Matchstick patterns: build growing patterns and find the rule", "nth term challenge: find the nth term of 4, 9, 14, 19...", "Pattern detective: given the first three terms, predict the 100th"],
        misconceptions: ["Writing the nth term as 'difference × n' without the adjustment", "Finding the difference but not checking it works for the first term", "Confusing the term number with the term value"],
      },
      {
        id: "algebra-y7", name: "Algebra Intro", icon: "Sigma", description: "Expressions and equations.",
        objectives: ["Simplify expressions by collecting like terms", "Expand single brackets", "Solve one and two-step equations"],
        guidance: "Start by simplifying like terms: 3a + 2a = 5a (compare to 3 apples + 2 apples). Then expand brackets: 3(x+4) = 3x+12. Solve equations using the balance method — do the same to both sides. Use the 'opposite operation' approach: to undo +5, subtract 5.",
        activities: ["Like terms sort: sort expression cards into simplified groups", "Balance model: use an interactive balance to solve equations", "Expand-and-simplify: give problems that combine expanding and collecting"],
        misconceptions: ["Adding unlike terms (3a + 2b ≠ 5ab)", "Only multiplying the first term in a bracket (3(x+4) ≠ 3x+4)", "Forgetting to do the same operation to both sides when solving"],
      },
    ],
  },
  {
    id: "year8",
    name: "Year 8",
    subtitle: "Ages 12-13",
    overview: "Year 8 deepens algebra (linear equations, factorising), introduces Pythagoras' theorem, and extends percentages and probability. This year prepares students for the Checkpoint Stage 9 assessment and the transition to IGCSE.",
    topics: [
      {
        id: "linear-equations-y8", name: "Linear Equations", icon: "Sigma", description: "Solving equations with unknowns on both sides.",
        objectives: ["Solve equations with the variable on both sides", "Solve equations involving brackets", "Set up equations from word problems"],
        guidance: "Teach the method: expand brackets, collect like terms, move variables to one side, solve. Use the balance model throughout. For equations with x on both sides (e.g. 3x+5 = 2x+11), subtract the smaller x-term from both sides first.",
        activities: ["Equation balance: model equations on an interactive balance", "Story to equation: translate word problems into equations", "Solve and check: solve the equation, then substitute to verify"],
        misconceptions: ["Moving the x-term but forgetting to change its sign", "Not expanding brackets before collecting terms", "Dividing only one side instead of both sides"],
      },
      {
        id: "percentages-y8", name: "Percentages & Finance", icon: "Percent", description: "Percentage change, profit and loss.",
        objectives: ["Calculate percentage increase and decrease", "Calculate profit, loss and interest", "Solve reverse percentage problems"],
        guidance: "Teach percentage change = (change ÷ original) × 100. For increases, multiply by (1 + percentage as decimal). For reverse percentages ('a price after 20% increase is $120, find the original'), divide by the multiplier: $120 ÷ 1.20 = $100. Use real shopping and banking examples.",
        activities: ["Sale calculator: find sale prices and original prices", "Interest investigation: compare simple and compound interest on the same amount", "Business maths: calculate profit margins on a 'product'"],
        misconceptions: ["Calculating percentage decrease by subtracting the percentage from 100 and multiplying, but forgetting the original", "Reverse percentage: dividing by the percentage instead of the multiplier", "Confusing profit percentage (on cost) with markup percentage (on selling price)"],
      },
      {
        id: "pythagoras-y8", name: "Pythagoras' Theorem", icon: "Triangle", description: "a² + b² = c².",
        objectives: ["State and apply Pythagoras' theorem", "Find the hypotenuse of a right-angled triangle", "Find a shorter side using Pythagoras"],
        guidance: "Start by drawing squares on the sides of a right-angled triangle and showing that the areas of the two smaller squares equal the large square. Then teach the formula a² + b² = c². Emphasise that c is always the hypotenuse (opposite the right angle, longest side). Have students check by measuring.",
        activities: ["Square area proof: draw squares on triangle sides and compare areas", "Rope triangles: make a 3-4-5 triangle with rope to see the right angle", "Real-world Pythagoras: find the diagonal of a TV or a classroom"],
        misconceptions: ["Using the hypotenuse as a shorter side in the formula", "Forgetting to square-root the final answer (c² = 25, writing c = 25 instead of 5)", "Applying Pythagoras to non-right-angled triangles"],
      },
      {
        id: "probability-y8", name: "Probability", icon: "Dice", description: "Basic probability and events.",
        objectives: ["Calculate probability as a fraction/decimal", "Understand that probabilities sum to 1", "Find probabilities of combined events"],
        guidance: "Start with P(event) = favourable outcomes ÷ total outcomes. Use fractions, decimals and percentages. Teach that probabilities range from 0 (impossible) to 1 (certain). For combined events, introduce sample spaces (listing all outcomes) and tree diagrams for two events.",
        activities: ["Dice probability: list all outcomes of rolling two dice", "Spinner experiment: test theoretical vs experimental probability", "Tree diagrams: draw tree diagrams for coin and dice combinations"],
        misconceptions: ["Thinking a 1/6 probability means it happens once every six times (it's an expectation, not a guarantee)", "Adding probabilities for combined events instead of multiplying (for independent events)", "Not listing all possible outcomes before calculating"],
      },
    ],
  },
];

/* ===================== CAMBRIDGE CHECKPOINT ===================== */

const CHECKPOINT_SECTIONS: TeachingSection[] = [
  {
    id: "stage6-maths",
    name: "Stage 6 Maths",
    subtitle: "Cambridge Primary Checkpoint — Year 6",
    overview: "Stage 6 Maths is the Cambridge Primary Checkpoint assessment. The topics cover number, geometry, handling data, algebra basics, and fractions/decimals. Focus on exam technique: reading questions carefully, showing working, and checking units. Use past-paper questions regularly.",
    topics: [
      {
        id: "cp6-number", name: "Number", icon: "Hash", description: "Place value, operations and ordering.",
        objectives: ["Convert between fractions, decimals and percentages", "Round to specified decimal places", "Calculate percentages of amounts", "Order positive and negative numbers"],
        guidance: "Ensure students can convert fluently between fractions, decimals and percentages (1/2=0.5=50%, 1/4=0.25=25%, 3/4=0.75=75%). Teach rounding by looking at the next digit. Use real-world contexts like shopping and measurements. For percentages, teach finding 10% first then building up.",
        activities: ["Conversion table: complete a FDP conversion grid", "Percentage shopping: find 15% of various prices using the 10%+5% method", "Rounding relay: a team competition rounding to different places"],
        misconceptions: ["Rounding 4.782 to 2dp as 4.79 instead of 4.78 (looking at the wrong digit)", "Converting 4/5 as 0.45 instead of 0.8", "Subtracting negatives incorrectly (7 − (−3) = 4 instead of 10)"],
      },
      {
        id: "cp6-geometry", name: "Geometry & Measure", icon: "Shapes", description: "Angles, area, perimeter and volume.",
        objectives: ["Find angles using triangle and straight-line rules", "Calculate area and perimeter of rectangles and triangles", "Calculate volume of cuboids", "Use circle vocabulary (radius, diameter)"],
        guidance: "Reinforce that angles in a triangle = 180° and on a line = 180°. Teach area of rectangle = l×w, triangle = ½×b×h, and volume = l×w×h. Ensure students know diameter = 2 × radius. Always stress units (cm, cm², cm³).",
        activities: ["Missing angle cards: find the missing angle in various triangles", "Volume models: build cuboids with blocks and calculate volume", "Circle parts: label a circle with radius, diameter, circumference"],
        misconceptions: ["Using base × height for triangle area without halving", "Confusing area (cm²) and perimeter (cm) units", "Confusing radius and diameter"],
      },
      {
        id: "cp6-handling-data", name: "Handling Data", icon: "BarChart3", description: "Mean, median, mode, range and charts.",
        objectives: ["Calculate mean, median, mode and range", "Read and interpret bar charts and pie charts", "Understand probability as fractions"],
        guidance: "Teach the four averages with clear definitions. Emphasise that median requires sorting first. For pie charts, show that the whole circle = 360°, and each category gets a proportional slice. Use real data from the class.",
        activities: ["Class data averages: collect heights, find mean/median/mode/range", "Pie chart construction: draw pie charts from frequency data", "Probability spinner: calculate and test theoretical probabilities"],
        misconceptions: ["Finding median without sorting", "Confusing mode (most frequent) with the highest value", "For pie charts, not converting frequencies to angles (frequency ÷ total × 360)"],
      },
      {
        id: "cp6-algebra", name: "Algebra Basics", icon: "Sigma", description: "Variables, simple equations and patterns.",
        objectives: ["Use letters for unknowns", "Solve one-step and two-step equations", "Find the nth term of simple sequences", "Simplify expressions by collecting like terms"],
        guidance: "Introduce algebra as 'finding the mystery number'. Use the balance method for solving equations. For sequences, teach that the nth term = difference × n + adjustment. Check the formula works for the first term. Keep notation clear and consistent.",
        activities: ["Mystery number puzzles: 'Think of a number...' problems", "Balance scales: model equation solving visually", "nth term detective: find the rule for given sequences"],
        misconceptions: ["Not doing the same to both sides when solving equations", "Writing the nth term without checking the first term", "Confusing 3x with x+3"],
      },
      {
        id: "cp6-fractions", name: "Fractions & Decimals", icon: "PieChart", description: "Equivalent fractions, comparing and converting.",
        objectives: ["Simplify and create equivalent fractions", "Compare and order fractions", "Convert between fractions and decimals", "Add and subtract simple fractions"],
        guidance: "Teach equivalent fractions by multiplying or dividing top and bottom by the same number. For comparing, convert to a common denominator or to decimals. For addition, emphasise the need for a common denominator before adding.",
        activities: ["Fraction wall: build and compare fractions using a wall", "Common denominator game: add fractions by finding common denominators", "Fraction-decimal match: pair equivalent fractions and decimals"],
        misconceptions: ["Adding denominators as well as numerators (1/2 + 1/4 = 2/6)", "Thinking a bigger denominator means a bigger fraction (1/4 < 1/2)", "Not simplifying the final answer"],
      },
    ],
  },
  {
    id: "stage6-science",
    name: "Stage 6 Science",
    subtitle: "Cambridge Primary Checkpoint — Year 6",
    overview: "Stage 6 Science covers living things, materials and states, forces and energy, and Earth and space. Focus on using correct scientific vocabulary and understanding concepts rather than memorising facts. Practical experiments reinforce each topic.",
    topics: [
      {
        id: "cp6-living-things", name: "Living Things", icon: "Leaf", description: "Plants, animals and the human body.",
        objectives: ["Know the seven life processes (MRS GREN)", "Understand photosynthesis and plant parts", "Group animals by diet and characteristics", "Identify major human organs and their functions"],
        guidance: "Use MRS GREN as a memorable framework. Teach photosynthesis as a word equation: sunlight + CO₂ + water → glucose + oxygen. Use real plants to label parts. For animals, group by vertebrate/invertebrate and by diet. Use body models or diagrams for organs.",
        activities: ["Plant dissection: examine and label flower parts", "MRS GREN sorting: sort pictures of living things by which processes they show", "Food chain building: create food chains with cards"],
        misconceptions: ["Thinking plants 'breathe in' carbon dioxide and 'breathe out' oxygen all the time (they respire too)", "Classifying a butterfly as a vertebrate (it's an invertebrate)", "Thinking the heart makes blood, rather than pumping it"],
      },
      {
        id: "cp6-materials", name: "Materials & States", icon: "FlaskConical", description: "Solids, liquids, gases and changes of state.",
        objectives: ["Describe properties of solids, liquids and gases", "Name state changes (melting, freezing, evaporating, condensing)", "Distinguish reversible and irreversible changes", "Identify conductors and insulators"],
        guidance: "Use particle models to explain states. Show ice melting and water boiling as examples of state changes. Teach that melting and freezing are reversals, as are evaporating and condensing. Burning and cooking are irreversible — emphasise the difference. Test materials for conductivity.",
        activities: ["Ice observation: watch ice melt and record the temperature", "Reversible or not? — sort changes into two groups", "Circuit test: test which materials conduct electricity"],
        misconceptions: ["Confusing melting and dissolving (sugar dissolving is not melting)", "Thinking evaporation only happens at boiling point", "Confusing thermal and electrical conduction"],
      },
      {
        id: "cp6-forces", name: "Forces & Energy", icon: "Zap", description: "Pushes, pulls, friction and electricity.",
        objectives: ["Identify forces as pushes and pulls", "Explain friction and its effects", "Understand simple circuits", "Know that magnets attract magnetic materials"],
        guidance: "Start with pushes and pulls in everyday life. Demonstrate friction with different surfaces. Build simple circuits with bulbs and batteries — show that a break in the circuit stops the flow. Use magnets to test which materials are magnetic (iron, nickel, cobalt).",
        activities: ["Friction ramp: test how far a toy car travels on different surfaces", "Circuit building: build circuits with bulbs, batteries, and switches", "Magnetic hunt: test classroom objects with a magnet"],
        misconceptions: ["Thinking friction is always 'bad' (it's essential for walking and braking)", "Believing a circuit needs only a battery (it needs a complete loop)", "Thinking all metals are magnetic (only iron, nickel, cobalt)"],
      },
      {
        id: "cp6-earth-space", name: "Earth & Space", icon: "Globe", description: "The solar system, day and night, seasons.",
        objectives: ["Describe the solar system and planets", "Explain day and night using the Earth's rotation", "Explain seasons using the Earth's tilt", "Describe the Moon's phases"],
        guidance: "Use models — a globe and a torch for day/night and seasons. Show that the Earth rotates once every 24 hours (day and night) and orbits the Sun once a year. The tilt causes seasons. Use a ball orbiting a globe to show Moon phases. Emphasise that the Sun is a star.",
        activities: ["Day-night demo: use a globe and torch to model rotation", "Seasons model: use a tilted globe to show why seasons happen", "Moon phase diary: observe and record moon phases over a month"],
        misconceptions: ["Thinking seasons are caused by distance from the Sun (they're caused by the tilt)", "Thinking the Moon produces its own light (it reflects sunlight)", "Confusing rotation (spin) and revolution (orbit)"],
      },
    ],
  },
  {
    id: "stage9-maths",
    name: "Stage 9 Maths",
    subtitle: "Cambridge Lower Secondary Checkpoint — Year 9",
    overview: "Stage 9 Maths is the Lower Secondary Checkpoint. It extends number work to standard form and indices, introduces formal algebra (equations, factorising, sequences), geometry with Pythagoras and trigonometry, and statistics with probability. This is a key preparation year for IGCSE.",
    topics: [
      {
        id: "cp9-number", name: "Number & Calculation", icon: "Hash", description: "Powers, standard form and percentages.",
        objectives: ["Use index laws to multiply and divide powers", "Convert between ordinary and standard form", "Calculate percentage changes", "Calculate simple interest"],
        guidance: "Teach index laws: when multiplying, add indices; when dividing, subtract. For standard form, A × 10ⁿ where 1 ≤ A < 10. Large numbers have positive powers, small numbers have negative powers. Percentage change = change ÷ original × 100. Simple interest = P × R × T.",
        activities: ["Index law investigation: explore patterns with powers of 2", "Standard form conversion: convert large and small numbers", "Interest calculator: compare simple interest on different amounts"],
        misconceptions: ["Adding coefficients in standard form (3.2×10⁵ + 4.8×10⁵ ≠ 8×10¹⁰ — add coefficients when powers match)", "Writing 0.00036 as 3.6×10⁻³ instead of 3.6×10⁻⁴", "Calculating percentage increase by adding the percentage to the original without multiplying"],
      },
      {
        id: "cp9-algebra", name: "Algebra", icon: "Sigma", description: "Equations, formulas and sequences.",
        objectives: ["Solve equations with brackets and variables on both sides", "Factorise expressions by taking out common factors", "Find the nth term of linear sequences", "Substitute into and rearrange formulas"],
        guidance: "Teach solving equations step-by-step: expand, collect like terms, move variables, solve. For factorising, find the highest common factor. For nth term: find the difference (coefficient of n), then find the adjustment. For rearranging, do the same operation to both sides to isolate the target variable.",
        activities: ["Equation relay: race to solve increasingly complex equations", "Factorising challenge: factorise expressions with common factors", "nth term patterns: use matchstick patterns to derive nth term rules"],
        misconceptions: ["Forgetting to change the sign when moving a term across the equals", "Not finding the highest common factor when factorising", "nth term: writing the difference as the coefficient but getting the adjustment wrong"],
      },
      {
        id: "cp9-geometry", name: "Geometry & Trigonometry", icon: "Triangle", description: "Pythagoras, angles and transformations.",
        objectives: ["Apply Pythagoras' theorem to find missing sides", "Calculate area and circumference of circles", "Use bearings (clockwise from North)", "Calculate surface area of cuboids"],
        guidance: "Reinforce Pythagoras: a² + b² = c². For circles, teach area = πr² and circumference = 2πr. Bearings are measured clockwise from North, written as three digits (045°, not 45°). The reverse bearing is found by adding or subtracting 180°. Surface area of a cuboid = 2(lw + lh + wh).",
        activities: ["Pythagoras treasure hunt: find missing sides around the room", "Circle calculations: find area and circumference of given circles", "Bearings map: draw bearings on a map between points"],
        misconceptions: ["Using a shorter side as the hypotenuse in Pythagoras", "Forgetting bearings are 3 digits (writing 45° instead of 045°)", "Confusing area (πr²) and circumference (2πr)"],
      },
      {
        id: "cp9-statistics", name: "Statistics & Probability", icon: "BarChart3", description: "Averages, probability, and diagrams.",
        objectives: ["Calculate mean, median, mode and range", "Calculate probabilities as fractions", "Use tree diagrams for combined events", "Interpret Venn diagrams"],
        guidance: "Reinforce the four averages. For probability, P(event) = favourable ÷ total. For independent events, multiply along tree diagram branches. Venn diagrams show overlaps between sets. Use real data and dice/coin experiments to make probability tangible.",
        activities: ["Tree diagram dice: draw tree diagrams for two-dice events", "Venn diagram survey: survey the class and display results in a Venn diagram", "Probability experiment: test theoretical vs experimental probability with dice"],
        misconceptions: ["Adding probabilities for independent events (should multiply)", "Not sorting data before finding the median", "Confusing the regions in a Venn diagram (only A, only B, both, neither)"],
      },
    ],
  },
  {
    id: "stage9-science",
    name: "Stage 9 Science",
    subtitle: "Cambridge Lower Secondary Checkpoint — Year 9",
    overview: "Stage 9 Science deepens understanding of biology (cells, body systems), chemistry (atoms, reactions), and physics (energy, waves). This is the bridge to IGCSE science. Focus on scientific method, correct terminology, and practical skills.",
    topics: [
      {
        id: "cp9-cells", name: "Cells & Body Systems", icon: "Leaf", description: "Cell structure and organ systems.",
        objectives: ["Identify plant and animal cell parts and their functions", "Describe the difference between plant and animal cells", "Explain how cells form tissues, organs, and systems", "Describe the key body systems"],
        guidance: "Use microscopes if available to examine onion cells and cheek cells. Compare plant cells (cell wall, chloroplasts, vacuole) with animal cells. Build the hierarchy: cells → tissues → organs → systems → organism. Use body models to show major systems (digestive, respiratory, circulatory).",
        activities: ["Onion cell microscopy: prepare and examine onion cells", "Cell model: build 3D cell models with labelled parts", "Body system map: draw and label the major body systems"],
        misconceptions: ["Thinking plant and animal cells are identical", "Confusing the cell wall (plants only, rigid) with the cell membrane (both, flexible)", "Not understanding the cell-tissue-organ-system hierarchy"],
      },
      {
        id: "cp9-reactions", name: "Chemical Reactions", icon: "FlaskConical", description: "Atoms, elements, compounds and reactions.",
        objectives: ["Distinguish atoms, elements, and compounds", "Write simple word equations for reactions", "Identify acids, bases, and neutralisation", "Describe factors affecting reaction rate"],
        guidance: "Start with the particle model: everything is made of atoms. Elements are one type of atom; compounds are two or more bonded. Teach reaction types: combustion, oxidation, neutralisation (acid + base → salt + water). For reaction rates, show how temperature, surface area, and concentration affect speed.",
        activities: ["Reaction in a bag: mix baking soda and vinegar in a sealed bag", "Acid-base test: use indicator to test household substances", "Rate experiment: investigate how temperature affects reaction rate"],
        misconceptions: ["Confusing atoms and molecules (a molecule is two or more atoms bonded)", "Thinking a compound is just a mixture (it's chemically bonded)", "Believing mass is lost in a reaction (it's conserved)"],
      },
      {
        id: "cp9-energy", name: "Energy & Waves", icon: "Zap", description: "Energy stores, transfers, and wave properties.",
        objectives: ["Identify different energy stores", "Describe energy transfers and conservation", "Understand wave properties (amplitude, wavelength, frequency)", "Distinguish transverse and longitudinal waves"],
        guidance: "Teach that energy is never created or destroyed, only transferred. Use energy transfer diagrams (Sankey diagrams). For waves, use a slinky to show transverse and longitudinal waves. Define amplitude (height), wavelength (crest to crest), and frequency (waves per second).",
        activities: ["Energy transfer chain: track energy through a system (e.g. a lamp)", "Slinky waves: demonstrate transverse and longitudinal waves", "Pendulum investigation: how does height affect swing time?"],
        misconceptions: ["Thinking energy is 'used up' (it's transferred, not destroyed)", "Confusing amplitude and wavelength", "Not distinguishing between wave speed and frequency"],
      },
    ],
  },
];

/* ===================== IGCSE ===================== */

const IGCSE_SECTIONS: TeachingSection[] = [
  {
    id: "igcse-maths",
    name: "IGCSE Mathematics",
    subtitle: "Core and Extended — Years 10-11",
    overview: "IGCSE Mathematics covers number, algebra, geometry, statistics, and (for Extended) calculus basics. Focus on exam technique: show all working, check units, and practise past papers regularly. The Extended paper includes harder algebra and an introduction to differentiation.",
    topics: [
      {
        id: "ig-maths-number", name: "Number", icon: "Hash", description: "Standard form, percentages, ratio and proportion.",
        objectives: ["Convert between ordinary and standard form", "Calculate compound interest and depreciation", "Solve ratio and proportion problems", "Calculate speed, distance and time"],
        guidance: "Ensure fluency in standard form. For compound interest, multiply by (1 + rate)ⁿ; for depreciation, multiply by (1 − rate)ⁿ. For ratio problems, find the value of one part first. Speed = distance ÷ time; ensure consistent units. Use past-paper questions for exam-style practice.",
        activities: ["Compound interest comparison: compare two investment options", "Ratio sharing: divide amounts in given ratios", "Speed-distance-time problems: solve past-paper style questions"],
        misconceptions: ["Standard form: not ensuring A is between 1 and 10", "Compound interest: using simple interest formula instead of compound", "Inverse proportion: treating it as direct proportion"],
      },
      {
        id: "ig-maths-algebra", name: "Algebra", icon: "Sigma", description: "Equations, factorising, sequences and functions.",
        objectives: ["Solve linear and simultaneous equations", "Factorise quadratics and difference of squares", "Find nth terms of linear and quadratic sequences", "Work with function notation and composition"],
        guidance: "Teach simultaneous equations by elimination and substitution. For factorising quadratics, find two numbers that multiply to the constant and add to the coefficient of x. For function composition, work from the inside out. Emphasise showing every step for method marks.",
        activities: ["Simultaneous equation relay: solve pairs of equations", "Quadratic factory: factorise a set of quadratics", "Function composition: find fg(x) for given functions"],
        misconceptions: ["Simultaneous equations: not eliminating correctly (signs)", "Factorising: giving up when the leading coefficient isn't 1", "Function composition: applying functions in the wrong order"],
      },
      {
        id: "ig-maths-geometry", name: "Geometry & Mensuration", icon: "Shapes", description: "Angles, circles, area, volume and trigonometry.",
        objectives: ["Use Pythagoras and trigonometry (SOH CAH TOA)", "Calculate area and circumference of circles", "Find volume and surface area of prisms and cylinders", "Use bearings correctly"],
        guidance: "Ensure students know SOH CAH TOA and when to use each. For area of a sector, use the fraction of the circle (angle/360 × πr²). Volume of a cylinder = πr²h. Bearings are 3-digit, clockwise from North. Practise with past-paper multi-step problems.",
        activities: ["Trigonometry treasure hunt: find sides and angles around the room", "Volume challenge: calculate volumes of various 3D shapes", "Bearings navigation: solve bearing problems on a map"],
        misconceptions: ["Using sin when cos is needed (not identifying the sides correctly)", "Forgetting to square-root in Pythagoras", "Bearings: measuring from the wrong point or direction"],
      },
      {
        id: "ig-maths-statistics", name: "Statistics & Probability", icon: "BarChart3", description: "Averages, histograms, probability and tree diagrams.",
        objectives: ["Calculate mean, median, mode from frequency tables", "Draw and interpret histograms", "Use tree diagrams for combined probability", "Calculate conditional probability"],
        guidance: "For frequency tables, teach that the mean = sum of (frequency × value) ÷ total frequency. Histograms have frequency density on the y-axis (not frequency). For tree diagrams, multiply along branches for 'and', add between branches for 'or'. Use past-paper probability questions.",
        activities: ["Frequency table averages: calculate averages from grouped data", "Histogram drawing: construct histograms from frequency density", "Tree diagram problems: solve combined probability questions"],
        misconceptions: ["Drawing bar charts instead of histograms (not using frequency density)", "Tree diagrams: multiplying when you should add (or vice versa)", "Frequency table mean: not multiplying frequency by value"],
      },
      {
        id: "ig-maths-calculus", name: "Calculus Basics (Extended)", icon: "Sigma", description: "Differentiation and simple integration.",
        objectives: ["Differentiate using the power rule", "Find the gradient of a curve at a point", "Find stationary points", "Integrate simple functions"],
        guidance: "This is Extended-only. Teach the power rule: d/dx(xⁿ) = n·xⁿ⁻¹. To find the gradient at a point, differentiate then substitute. Set dy/dx = 0 to find stationary points. Integration is the reverse: add 1 to the power, divide by the new power, add +c. Keep it focused — this is introductory.",
        activities: ["Gradient investigation: find gradients of y=x² at different points", "Stationary point hunt: find and classify stationary points", "Integration practice: integrate a set of functions"],
        misconceptions: ["Differentiating a constant as 1 instead of 0", "Forgetting the +c in indefinite integration", "Not substituting the x-value after differentiating to find a gradient"],
      },
    ],
  },
  {
    id: "igcse-english",
    name: "IGCSE English",
    subtitle: "Language — Years 10-11",
    overview: "IGCSE English Language focuses on grammar, reading comprehension, and directed writing. Students must analyse texts, infer meaning, and produce different text types (letters, reports, articles). Emphasise planning, structure, and using appropriate tone for the audience.",
    topics: [
      {
        id: "ig-english-grammar", name: "Grammar & Punctuation", icon: "PenLine", description: "Sentence structure, clauses and punctuation.",
        objectives: ["Identify and use different sentence types", "Use correct punctuation including apostrophes and speech marks", "Distinguish active and passive voice", "Use a range of clause structures"],
        guidance: "Teach sentence types (simple, compound, complex). Practise apostrophes for possession (singular and plural). Show the difference between active and passive voice and when each is appropriate. Use student writing to identify and correct errors. Exam focus: accuracy earns marks.",
        activities: ["Sentence builder: create simple, compound and complex sentences", "Apostrophe correction: fix apostrophe errors in a text", "Active to passive: convert sentences between voices"],
        misconceptions: ["Using 'it's' for possession (it's = it is; possessive is 'its')", "Plural apostrophe errors (students' vs student's)", "Confusing 'there', 'their' and 'they're'"],
      },
      {
        id: "ig-english-comprehension", name: "Reading Comprehension", icon: "BookOpen", description: "Inference, analysis and writer's effects.",
        objectives: ["Make inferences from text using evidence", "Identify literary devices (metaphor, simile, personification)", "Explain the effect of word choices", "Distinguish fact from opinion"],
        guidance: "Teach PEE/PEEL (Point, Evidence, Explain, Link) for structured answers. Have students quote specific words and explain their effect. For inference, ask 'how do you know?' and require evidence. Analyse writer's craft: why did they choose that word? Exam focus: always support points with quotations.",
        activities: ["PEE paragraph writing: analyse a short text extract", "Device hunt: find and label literary devices in a passage", "Effect explanation: explain what a specific word choice suggests"],
        misconceptions: ["Quoting without explaining the effect", "Identifying a device but not explaining why it's used", "Giving opinions instead of evidence-based analysis"],
      },
      {
        id: "ig-english-writing", name: "Directed Writing", icon: "PenLine", description: "Formal letters, reports, articles, tone and structure.",
        objectives: ["Plan and structure different text types", "Use appropriate tone and register", "Apply correct formats for letters, reports and articles", "Write for a specific audience and purpose"],
        guidance: "Teach the format for each text type: formal letters (address, date, salutation, 'Yours faithfully/sincerely'), reports (title, sections, conclusion), articles (headline, lead paragraph). Emphasise planning before writing. Show model answers and annotate them. Exam focus: match the tone to the audience.",
        activities: ["Formal letter writing: write a letter of complaint", "Report writing: write a report on a school event", "Article challenge: write a persuasive article on a given topic"],
        misconceptions: ["Using 'Yours sincerely' with 'Dear Sir/Madam' (should be 'Yours faithfully')", "Writing a report like an essay (reports need sub-headings)", "Using informal language in formal writing"],
      },
    ],
  },
  {
    id: "igcse-physics",
    name: "IGCSE Physics",
    subtitle: "Elective — Years 10-11",
    overview: "IGCSE Physics covers forces and motion, energy and work, electricity, waves, and thermal physics. Focus on applying formulas, showing working with units, and understanding concepts. Practical skills are important. Use past papers to practise exam-style calculations.",
    topics: [
      {
        id: "ig-phy-motion", name: "Forces & Motion", icon: "Zap", description: "Speed, acceleration, Newton's laws and momentum.",
        objectives: ["Calculate speed, velocity and acceleration", "Apply Newton's laws of motion", "Calculate momentum and understand conservation", "Analyse motion graphs (distance-time, velocity-time)"],
        guidance: "Teach the key formulas: v = d/t, a = Δv/t, F = ma, p = mv. Use motion graphs to distinguish speed (gradient of d-t) and acceleration (gradient of v-t). Newton's 3 laws: 1st (inertia), 2nd (F=ma), 3rd (action-reaction). Momentum is conserved in collisions. Always include units.",
        activities: ["Motion graph analysis: interpret d-t and v-t graphs", "Newton's laws demonstrations: show each law with simple equipment", "Momentum calculation: solve collision problems"],
        misconceptions: ["Confusing speed (scalar) and velocity (vector)", "Thinking a constant velocity means zero force (balanced forces, not no force)", "Forgetting that momentum is conserved (not 'lost') in collisions"],
      },
      {
        id: "ig-phy-energy", name: "Energy & Work", icon: "Flame", description: "Energy stores, work, power and efficiency.",
        objectives: ["Calculate work done (W = Fd)", "Calculate power (P = W/t)", "Use KE = ½mv² and GPE = mgh", "Calculate efficiency"],
        guidance: "Teach the energy formulas and when to use each. Work = force × distance (in the direction of the force). Power = energy ÷ time. Efficiency = useful output ÷ total input × 100%. Show that energy is conserved but some is 'wasted' as heat. Use real machines as examples.",
        activities: ["Efficiency calculation: find the efficiency of different devices", "Energy rollercoaster: track energy conversions in a rollercoaster", "Power comparison: compare the power of different appliances"],
        misconceptions: ["Calculating work without the distance in the direction of force", "Efficiency over 100% (impossible — means a calculation error)", "Confusing energy (joules) and power (watts)"],
      },
      {
        id: "ig-phy-electricity", name: "Electricity", icon: "Plug", description: "Current, voltage, resistance and circuits.",
        objectives: ["Apply Ohm's law (V = IR)", "Calculate electrical energy and power", "Analyse series and parallel circuits", "Understand mains electricity and safety"],
        guidance: "Teach V = IR and ensure students can rearrange it. In series, current is the same and resistances add. In parallel, voltage is the same and total resistance is less than the smallest. Electrical energy = VIt. Power = VI. Use circuit diagrams and build real circuits. Always check units (A, V, Ω, W, J).",
        activities: ["Circuit building: build series and parallel circuits", "Ohm's law investigation: find the resistance of a component", "Energy calculation: calculate the cost of running appliances"],
        misconceptions: ["Adding resistances in parallel as a simple sum (must use 1/R formula)", "Confusing current (flow) and voltage (push)", "Not converting units (mA to A, kΩ to Ω)"],
      },
      {
        id: "ig-phy-waves", name: "Waves & Light", icon: "Zap", description: "Wave properties, reflection, refraction and the EM spectrum.",
        objectives: ["Use the wave equation (v = fλ)", "Describe reflection and refraction", "Explain total internal reflection", "Order the electromagnetic spectrum"],
        guidance: "Teach v = f×λ and ensure consistent units. Reflection: angle of incidence = angle of reflection (from the normal). Refraction: light bends towards the normal entering a denser medium. Total internal reflection occurs above the critical angle. EM spectrum: radio (longest) to gamma (shortest). All EM waves travel at 3×10⁸ m/s in a vacuum.",
        activities: ["Wave equation practice: solve v=fλ problems", "Ray diagrams: draw reflection and refraction diagrams", "EM spectrum ordering: arrange EM waves by wavelength and frequency"],
        misconceptions: ["Measuring angles from the surface instead of the normal", "Thinking refraction doesn't occur (light bends, not just slows)", "Confusing wavelength and frequency (inversely related)"],
      },
      {
        id: "ig-phy-thermal", name: "Thermal Physics", icon: "Flame", description: "Heat transfer, states of matter and specific heat capacity.",
        objectives: ["Describe conduction, convection and radiation", "Use E = mcΔT for specific heat capacity", "Explain state changes and latent heat", "Understand particle model of matter"],
        guidance: "Teach the three transfer methods with real examples. Conduction (solids, metals best), convection (fluids), radiation (vacuum). E = mcΔT: energy = mass × specific heat capacity × temperature change. During state changes, temperature is constant (latent heat). Use particle diagrams to explain states.",
        activities: ["Heat transfer demos: show conduction (metal rod), convection (water + dye), radiation (heat lamp)", "Specific heat calculation: calculate energy for different substances", "State change graph: plot temperature vs time for melting ice"],
        misconceptions: ["Thinking convection happens in solids (it requires fluid movement)", "Calculating energy without converting mass to kg", "Not understanding that temperature stays constant during state change"],
      },
    ],
  },
  {
    id: "igcse-chemistry",
    name: "IGCSE Chemistry",
    subtitle: "Elective — Years 10-11",
    overview: "IGCSE Chemistry covers atomic structure, the Periodic Table, chemical reactions, and quantitative chemistry. Focus on balancing equations, understanding atomic structure, and applying chemical formulas. Practical work and observation skills are essential.",
    topics: [
      {
        id: "ig-chem-atomic", name: "Atomic Structure", icon: "Atom", description: "Atoms, elements, compounds and the Periodic Table.",
        objectives: ["Describe atomic structure (protons, neutrons, electrons)", "Write electronic configurations", "Explain isotopes", "Use the Periodic Table to predict properties"],
        guidance: "Teach that atomic number = protons, mass number = protons + neutrons. Electronic configuration fills shells (2, 8, 8...). Isotopes have the same protons but different neutrons. Show how Group number = outer electrons, and Period = electron shells. Use the Periodic Table constantly.",
        activities: ["Atom modelling: build atoms with protons, neutrons, electrons", "Configuration challenge: write electronic configurations for elements", "Periodic Table hunt: find elements by their properties"],
        misconceptions: ["Confusing mass number and atomic number", "Writing configurations without filling shells in order", "Thinking isotopes are different elements (same protons = same element)"],
      },
      {
        id: "ig-chem-reactions", name: "Chemical Reactions", icon: "FlaskConical", description: "Equations, acids, bases and rates of reaction.",
        objectives: ["Balance chemical equations", "Describe reactions of acids with metals, bases, and carbonates", "Explain factors affecting reaction rate", "Calculate reacting masses"],
        guidance: "Teach balancing by ensuring the same number of each atom on both sides. Acid + metal → salt + hydrogen; acid + base → salt + water; acid + carbonate → salt + water + CO₂. Reaction rate factors: temperature, concentration, surface area, catalyst. Use mole calculations for reacting masses.",
        activities: ["Equation balancing: balance a set of chemical equations", "Acid reaction tests: test acids with different metals and observe", "Rate investigation: how does concentration affect reaction rate?"],
        misconceptions: ["Changing the formula (subscript) instead of the coefficient when balancing", "Not knowing which gas is produced (acid + metal = H₂, not O₂)", "Thinking a catalyst is used up (it's not)"],
      },
    ],
  },
  {
    id: "igcse-biology",
    name: "IGCSE Biology",
    subtitle: "Elective — Years 10-11",
    overview: "IGCSE Biology covers cells, organisms, and ecosystems. Focus on biological vocabulary, understanding processes (photosynthesis, respiration), and interpreting data. Practical work includes microscopy and field studies.",
    topics: [
      {
        id: "ig-bio-cells", name: "Cells & Organisms", icon: "Leaf", description: "Cell structure, organisation and biological molecules.",
        objectives: ["Identify cell structures and their functions", "Describe the organisation hierarchy", "Explain diffusion and osmosis", "Test for biological molecules"],
        guidance: "Use microscopes to examine plant and animal cells. Teach cell specialisation (red blood cells, nerve cells, root hair cells). Diffusion is the movement of particles from high to low concentration. Osmosis is a special case involving water through a partially permeable membrane. Food tests: Benedict's (sugar), iodine (starch), Biuret (protein).",
        activities: ["Microscopy: examine and draw onion and cheek cells", "Osmosis experiment: potato cubes in different salt concentrations", "Food tests: test foods for sugar, starch, and protein"],
        misconceptions: ["Confusing diffusion and osmosis (osmosis is water only)", "Thinking cells are all the same (they're specialised)", "Not understanding that osmosis is a type of diffusion"],
      },
      {
        id: "ig-bio-ecosystems", name: "Ecosystems", icon: "Globe", description: "Food chains, cycles and human impact.",
        objectives: ["Construct food chains and webs", "Describe the carbon and water cycles", "Explain the effect of human activity on ecosystems", "Understand pyramids of biomass"],
        guidance: "Teach food chains (producer → consumer) and food webs (interconnected chains). The carbon cycle: photosynthesis removes CO₂, respiration and combustion add it. Pyramids of biomass show energy loss at each level (about 90% lost). Discuss deforestation, pollution, and climate change.",
        activities: ["Food web construction: build a food web from organism cards", "Carbon cycle diagram: draw and label the carbon cycle", "Biomass pyramid: create biomass pyramids for different ecosystems"],
        misconceptions: ["Thinking energy cycles (it flows through and is lost as heat)", "Confusing pyramids of numbers and pyramids of biomass", "Not understanding that decomposers recycle nutrients"],
      },
    ],
  },
  {
    id: "igcse-economics",
    name: "IGCSE Economics",
    subtitle: "Elective — Years 10-11",
    overview: "IGCSE Economics introduces the economic problem, markets, and the role of government. Focus on understanding key concepts (scarcity, supply and demand) and applying them to real-world situations. Use case studies and current events.",
    topics: [
      {
        id: "ig-econ-basics", name: "Economic Basics", icon: "TrendingUp", description: "Scarcity, choice and opportunity cost.",
        objectives: ["Define scarcity, choice and opportunity cost", "Explain the factors of production", "Distinguish between needs and wants", "Understand the basic economic problem"],
        guidance: "Start with the fundamental problem: unlimited wants, limited resources. Scarcity forces choice, and every choice has an opportunity cost (the next best alternative given up). Factors of production: land, labour, capital, enterprise. Use real examples to make it concrete.",
        activities: ["Opportunity cost scenarios: students make choices and identify opportunity costs", "Factors of production sort: classify resources", "Needs vs wants debate: classify items as needs or wants"],
        misconceptions: ["Confusing opportunity cost with the total cost of a choice (it's the next best alternative, not everything given up)", "Thinking 'capital' means money (in economics it means man-made resources)", "Confusing free goods and economic goods"],
      },
      {
        id: "ig-econ-markets", name: "Market Economics", icon: "TrendingUp", description: "Supply, demand and price determination.",
        objectives: ["Explain the law of demand and supply", "Show how equilibrium price is determined", "Analyse shifts in demand and supply", "Explain the effects of government intervention"],
        guidance: "Teach demand (willingness and ability to buy) and supply (willingness and ability to sell). Price is determined where demand meets supply (equilibrium). A shift in demand or supply changes the equilibrium. Government intervention: price ceilings, floors, taxes, subsidies. Use demand and supply diagrams.",
        activities: ["Demand and supply graphing: draw and shift curves", "Market simulation: run a classroom market to find equilibrium price", "Government intervention case study: analyse the effect of a tax"],
        misconceptions: ["Confusing a movement along the curve (caused by price) with a shift (caused by other factors)", "Thinking an increase in supply always means an increase in price (it usually means lower price)", "Not distinguishing between price ceilings and floors"],
      },
    ],
  },
  {
    id: "igcse-ict",
    name: "IGCSE ICT",
    subtitle: "Elective — Years 10-11",
    overview: "IGCSE ICT covers hardware, software, networks, and data handling. Focus on understanding how computers work, how networks connect them, and how data is processed and stored. Practical skills include using applications and understanding safety and ethics.",
    topics: [
      {
        id: "ig-ict-hardware", name: "Hardware & Software", icon: "Cpu", description: "Components, systems and software types.",
        objectives: ["Identify internal computer components and their functions", "Distinguish system and application software", "Explain input, output and storage devices", "Understand the difference between hardware and software"],
        guidance: "Teach the main components: CPU (processor), RAM (temporary memory), hard drive (storage), motherboard. System software (operating systems) manages the computer; application software does specific tasks. Input devices (keyboard, mouse, sensors), output devices (screen, printer, speaker). Use real components if available.",
        activities: ["Component matching: match components to their functions", "Software sort: classify software as system or application", "Design a computer: choose components for a specific purpose"],
        misconceptions: ["Confusing RAM and storage (RAM is temporary, storage is permanent)", "Thinking the CPU stores data (it processes, it doesn't store)", "Confusing input and output devices"],
      },
      {
        id: "ig-ict-networks", name: "Networks & Internet", icon: "Cpu", description: "Network types, internet and data security.",
        objectives: ["Explain LAN and WAN", "Describe how the internet works", "Understand network security threats", "Explain data protection and online safety"],
        guidance: "LAN (Local Area Network) covers a small area; WAN (Wide Area Network) covers a large area. The internet is a global network of networks. Teach security threats (viruses, hacking, phishing) and protections (firewall, antivirus, encryption). Discuss data privacy and safe online behaviour.",
        activities: ["Network diagram: draw a school LAN", "Security audit: identify threats and protections for a network", "Online safety debate: discuss privacy vs security"],
        misconceptions: ["Thinking the internet and the World Wide Web are the same (the web runs on the internet)", "Confusing LAN and WAN by size rather than geography", "Thinking a firewall blocks all threats (it's one layer of protection)"],
      },
    ],
  },
  {
    id: "igcse-business",
    name: "IGCSE Business Studies",
    subtitle: "Elective — Years 10-11",
    overview: "IGCSE Business Studies covers types of business, objectives, and stakeholders. Focus on understanding how businesses operate, make decisions, and interact with their stakeholders. Use case studies of real businesses.",
    topics: [
      {
        id: "ig-biz-types", name: "Types of Business", icon: "Briefcase", description: "Sole traders, partnerships and companies.",
        objectives: ["Describe sole traders, partnerships, private and public companies", "Explain the advantages and disadvantages of each", "Understand liability (limited vs unlimited)", "Compare business ownership types"],
        guidance: "Start with the simplest form (sole trader) and build up. Key distinctions: ownership, liability, raising finance, control, and legal requirements. Unlimited liability means the owner's personal assets are at risk; limited liability protects them. Use real businesses as examples (local sole traders vs public companies).",
        activities: ["Business comparison: compare ownership types in a table", "Case study analysis: analyse a real business's ownership structure", "Choose a structure: recommend a business type for a given scenario"],
        misconceptions: ["Confusing private and public companies (public companies sell shares on the stock exchange)", "Thinking limited liability means no risk (personal investment can still be lost)", "Not understanding that sole traders and partnerships have unlimited liability"],
      },
      {
        id: "ig-biz-objectives", name: "Business Objectives & Stakeholders", icon: "Briefcase", description: "Goals, stakeholders and conflict.",
        objectives: ["Identify common business objectives", "Describe different stakeholder groups", "Explain how stakeholder interests can conflict", "Understand how objectives influence decisions"],
        guidance: "Common objectives: survival, profit, growth, market share, social responsibility. Stakeholders: owners, employees, customers, suppliers, government, community. Each group has different interests that can conflict (e.g. employees want higher wages, owners want higher profits). Use case studies to show real conflicts.",
        activities: ["Stakeholder map: identify stakeholders for a given business", "Conflict resolution: discuss how to resolve stakeholder conflicts", "Objective debate: which objective is most important and why?"],
        misconceptions: ["Thinking all businesses aim only for profit (some prioritise growth or social goals)", "Confusing internal and external stakeholders", "Not recognising that stakeholder interests can conflict"],
      },
    ],
  },
];

/* ===================== EXPORTED PROGRAMMES ===================== */

export const TEACHER_PROGRAMMES: TeachingProgramme[] = [
  {
    id: "primary",
    name: "Primary (Years 1-8)",
    description: "General maths teaching guides for Years 1 through 8 — counting, arithmetic, fractions, geometry and more.",
    color: "#a855f7",
    icon: "GraduationCap",
    sections: PRIMARY_SECTIONS,
  },
  {
    id: "checkpoint",
    name: "Cambridge Checkpoint",
    description: "Teaching outlines for Cambridge Primary (Stage 6) and Lower Secondary (Stage 9) Checkpoint — Maths and Science.",
    color: "#f5c842",
    icon: "Award",
    sections: CHECKPOINT_SECTIONS,
  },
  {
    id: "igcse",
    name: "IGCSE",
    description: "Teaching guides for IGCSE subjects — Maths, English, Physics, Chemistry, Biology, Economics, ICT and Business Studies.",
    color: "#22d3ee",
    icon: "BookOpen",
    sections: IGCSE_SECTIONS,
  },
];

